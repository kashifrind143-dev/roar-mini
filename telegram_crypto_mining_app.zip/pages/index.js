import { useState, useEffect } from "react";

export default function Home() {
  const [balance, setBalance] = useState(0);
  const [autoMining, setAutoMining] = useState(false);

  useEffect(() => {
    let interval;
    if (autoMining) {
      interval = setInterval(() => {
        setBalance((b) => b + 1);
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [autoMining]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <h1 className="text-2xl font-bold">🚀 Telegram Mining Mini App</h1>
      <p className="mt-4">Balance: {balance} tokens</p>
      <div className="mt-6 flex gap-4">
        <button
          onClick={() => setBalance(balance + 1)}
          className="px-4 py-2 bg-blue-500 text-white rounded-lg shadow"
        >
          Click Mine
        </button>
        <button
          onClick={() => setAutoMining(!autoMining)}
          className="px-4 py-2 bg-green-500 text-white rounded-lg shadow"
        >
          {autoMining ? "Stop Auto Mining" : "Start Auto Mining"}
        </button>
      </div>
      <div className="mt-8">
        <button className="px-4 py-2 bg-purple-500 text-white rounded-lg shadow">
          Claim Task Reward
        </button>
      </div>
    </div>
  );
}
